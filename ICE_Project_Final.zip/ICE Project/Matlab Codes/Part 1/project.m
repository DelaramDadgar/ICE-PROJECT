clc
clear
close all
p1=100;   %kPa
t1=300;   %K
k=1.4;
cp=1.005;  %kJ/kg.K
cv=0.718;  %kJ/kg.K
R=0.2870;  %kJ/kg.K
r=12:0.01:18;   
v1=R * t1 / p1;
v5=v1;
t2=zeros(1,length(r));
t3=zeros(1,length(r));
t4=zeros(1,length(r));
t5=zeros(1,length(r));
p2=zeros(1,length(r));
p3=zeros(1,length(r));
p4=zeros(1,length(r));
p5=zeros(1,length(r));
v2=zeros(1,length(r));
v3=zeros(1,length(r));
v4=zeros(1,length(r));
q=zeros(1,length(r));

for i=1:length(r)
    t2(i)= 300 * (r(i)^0.4);
    p2(i)= 100 * (r(i)^1.4);
    v2(i)= R * t2(i) / p2(i);
    v3(i)= v2(i);
    p3(i)= 1.7 * p2(i);
    t3(i)= p3(i) * v3(i) / R;
    v4(i)= 0.95 * v3(i) + 0.05 * v1;
    p4(i)= p3(i);  
    t4(i)= p4(i) * v4(i) / R;
    q(i)= cv * (t3(i) - t2(i))+ cp * (t4(i) - t3(i));
    t5(i)= t4(i) * (v4(i)/v5)^0.4;
    p5(i)= p4(i) * (v4(i)/v5)^1.4;
end

t4(258)
r(258)
disp('properties at this compression ratio:')
disp('P1=')
disp(p1)
disp('P2=')
disp(p2(258))
disp('P3=')
disp(p3(258))
disp('P4=')
disp(p4(258))
disp('P5=')
disp(p5(258))
disp('T1=')
disp(t1)
disp('T2=')
disp(t2(258))
disp('T3=')
disp(t3(258))
disp('T4=')
disp(t4(258))
disp('T5=')
disp(t5(258))
disp('v1=')
disp(v1)
disp('v2=')
disp(v2(258))
disp('v3=')
disp(v3(258))
disp('v4=')
disp(v4(258))
disp('v5=')
disp(v5)
disp('Input Heat=')
disp(q(258))

plot(r,q,'LineWidth',1.5,'Color','b')
grid minor
xlabel('Compression ratio $(r_c)$','Interpreter','latex')
ylabel('Input Heat $(kJ/kg)$','Interpreter','latex')
title('Input Heat vs. Compression Ratio')

