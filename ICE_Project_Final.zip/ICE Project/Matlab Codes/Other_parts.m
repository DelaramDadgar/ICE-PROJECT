%%
%part 2
clc
clear 
close all
%Atkinson Cycle
p=[100 4254.4 5279.9 100 100];
v=[0.861 0.0591 0.0591 1.0046 0.861];

figure(1)
plot(v,p,'LineWidth',1.5)
grid minor
xlabel('v $(m^3/kg)$','Interpreter','latex')
ylabel('P $(kPa)$','Interpreter','latex')
title('P-v Diagram for Atkinson Cycle')

%%Comparison:
%Dual Cycle
p1=[100 4254.4 7232.6 7232.6 351.0256 100];
v1=[0.861 0.0591 0.0591 0.0992 0.861 0.861];
%Otto Cycle
p2=[100 4254.4 14124.3 331.99 100];
v2=[0.861 0.0591 0.0591 0.861 0.861];
%Diesel Cycle
p3=[100 4254.4 4254.4 392.07 100];
v3=[0.861 0.0591 0.1568 0.861 0.861];

figure(2)
plot(v1,p1,'LineWidth',1.5)
hold on
plot(v2,p2,'LineWidth',1.5)
hold on
plot(v3,p3,'LineWidth',1.5)
hold on
plot(v,p,'LineWidth',1.5)

grid minor
xlabel('v $(m^3/kg)$','Interpreter','latex')
ylabel('P $(kPa)$','Interpreter','latex')
title('P-v Diagram for Four Different Cycles')
legend('Dual Cycle','Otto Cycle','Diesel Cycle','Atkinson Cycle')

%%
%part 4
clc
clear
close all

%valve lift:
theta=0:720;
theta_d=250;
EVO= 130;
IVO= 340;
EVC= EVO + 250;
IVC= IVO + 250;
lmax_e= 10; %mm
lmax_i= 12; %mm
% l_e= lmax_e * sin(pi* ((theta-theta_o_e)/theta_d) );
l_e= zeros(1,length(theta));
l_i= zeros(1,length(theta));

for i=1:length(theta)
if theta(i) >= EVO && theta(i) <= EVC
    l_e(i) = lmax_e * sin(pi* ((theta(i) - EVO)/theta_d) );
end
end

for i=1:length(theta)
if theta(i) >= IVO && theta(i) <= IVC
    l_i(i) = lmax_i * sin(pi* ((theta(i) - IVO)/theta_d) );
end
end

figure(1)
plot(theta,l_e,'LineWidth',1.5)
hold on
plot(theta,l_i,'LineWidth',1.5)

grid minor
ylim([0 15])
ylabel('Valve Lift (mm)','Interpreter','latex','FontSize',12)
xlabel('Crank Angle (degree)','Interpreter','latex','FontSize',12)
title ('Valve Lift vs. Crank Angle','FontSize',13)
legend('Exhaust Valve','Intake Valve','FontSize',12)
xticks([0 90 180 270 360 540 720]);
xticklabels({'TDC','90','BDC','270','TDC','BDC','TDC'})
hold off


%velocity and mass flow rate:
pt= 105; %kPa
pu= 105:400; %kPa
t= 300; %K
R= 0.287; %kJ/kg.K
k= 1.4;
pu_cr= 199; %kPa
c_d= 0.7;
a_t= 0.0002; %m^2
rho= 1.22; %kg/m^3

vt= zeros(1,length(pu));
m_dot= zeros(1,length(pu));

for j=1:length(pu)
    if pu(j) <= pu_cr
        vt(j)= sqrt(   (2*R*1000*k/(k-1)) * t * (pt/pu(j))^((1-k)/k)  *  (1- (pt/pu(j))^((k-1)/k))  );
        m_dot(j)= c_d * rho * vt(j) * a_t;
    else
        vt(j)= sqrt( k * R * 1000 * t );
        m_dot(j)=  c_d * a_t * pu(j)*1000 * sqrt( (k/ (R*1000  *  t * (pt/pu(j))^((1-k)/k) ) )   *   (2/(k+1))^((k+1)/(k-1))   );
    end
end

figure(2)

plot (pu,vt)
ylim([0 450])
grid minor
ylabel('Velocity  (m/s)','Interpreter','latex','FontSize',12)
xlabel('Upstream Pressure (kPa)','Interpreter','latex','FontSize',12)
title('Velocity vs. Upstream Pressure','FontSize',13)
text(130,350,'Subsonic Reigon','FontSize',15)
text(300,400,'Sonic Reigon','FontSize',15)

hold on
xline(105,'--')
hold on
xline(199,'--')
hold off


figure(3)

plot (pu,m_dot)
grid minor
ylabel('Mass Flow Rate  (kg/s)','Interpreter','latex','FontSize',12)
xlabel('Upstream Pressure (kPa)','Interpreter','latex','FontSize',12)
title('Mass Flow Rate vs. Upstream Pressure','FontSize',13)
text(130,0.09,'Subsonic Reigon','FontSize',15)
text(280,0.1,'Sonic Reigon','FontSize',15)

hold on
xline(105,'--')
hold on
xline(199,'--')
hold off

