clc
clear 
close all
%Dual Cycle
p1=[100 4254.4 7232.6 7232.6 351.0256 100];
v1=[0.861 0.0591 0.0591 0.0992 0.861 0.861];
%Otto Cycle
p2=[100 4254.4 14124.3 331.99 100];
v2=[0.861 0.0591 0.0591 0.861 0.861];
%Diesel Cycle
p3=[100 4254.4 4254.4 392.07 100];
v3=[0.861 0.0591 0.1568 0.861 0.861];

plot(v1,p1,'LineWidth',1.5)
hold on
plot(v2,p2,'LineWidth',1.5)
hold on
plot(v3,p3,'LineWidth',1.5)
grid minor
xlabel('v $(m^3/kg)$','Interpreter','latex')
ylabel('P $(kPa)$','Interpreter','latex')
title('P-v Diagram for Three Different Cycles')
legend('Dual Cycle','Otto Cycle','Diesel Cycle')